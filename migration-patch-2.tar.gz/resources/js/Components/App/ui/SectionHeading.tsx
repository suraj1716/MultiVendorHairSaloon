// resources/js/Components/App/ui/SectionHeading.tsx
//
// Composable heading "kit" — built this way because different pages order
// the pieces differently (About.tsx: eyebrow -> divider -> title, all in one
// block. Home.tsx: eyebrow -> title -> divider, as three separate elements,
// with the divider also styled slightly larger and reused independently).
// Rather than force one rigid shape, each piece is exported separately so
// a page can assemble them in whatever order/size it actually needs, while
// still sharing one definition instead of four copy-pasted ones.
//
// - Eyebrow  -- small uppercase accent label
// - Divider  -- the accent line/diamond/line ornament (was "Ornament" in
//              About.tsx, "GoldDivider" in Home.tsx -- same shape, two sizes)
// - Heading  -- the h2/h1 title itself (two size presets matching the two
//              font-size/letter-spacing variants found across pages)
// - SectionHeading -- convenience wrapper for the About.tsx-style pattern
//              (eyebrow -> divider -> title, all merged, sm size). Equivalent
//              to calling the three pieces individually in that order.
import React from "react";

export type DividerSize = "sm" | "lg";
export type HeadingSize = "sm" | "lg";

const DIVIDER_LINE_WIDTH: Record<DividerSize, number> = { sm: 36, lg: 48 };

export function Divider({
  size = "sm",
  center = false,
  lineWidth,
  dotSize = 5,
  gap = 10,
  margin = "1.25rem 0",
  style,
}: {
  size?: DividerSize;
  center?: boolean;
  /** Overrides the size preset's line width in px */
  lineWidth?: number;
  dotSize?: number;
  gap?: number;
  margin?: string;
  style?: React.CSSProperties;
}) {
  const resolvedLineWidth = lineWidth ?? DIVIDER_LINE_WIDTH[size];
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap,
        margin,
        justifyContent: center ? "center" : "flex-start",
        ...style,
      }}
    >
      <div style={{ width: resolvedLineWidth, height: 1, background: "var(--color-accent)" }} />
      <div
        style={{
          width: dotSize,
          height: dotSize,
          background: "var(--color-accent)",
          transform: "rotate(45deg)",
          flexShrink: 0,
        }}
      />
      <div style={{ width: resolvedLineWidth, height: 1, background: "var(--color-accent)" }} />
    </div>
  );
}

/** @deprecated use Divider -- kept as an alias so existing imports don't break */
export const Ornament = Divider;

export function Eyebrow({
  children,
  center = false,
  style,
}: {
  children: React.ReactNode;
  center?: boolean;
  style?: React.CSSProperties;
}) {
  return (
    <span
      style={{
        fontFamily: "var(--font-body)",
        fontSize: "0.68rem",
        letterSpacing: "0.28em",
        textTransform: "uppercase",
        color: "var(--color-accent)",
        display: "block",
        textAlign: center ? "center" : "left",
        ...style,
      }}
    >
      {children}
    </span>
  );
}

const HEADING_STYLE: Record<HeadingSize, React.CSSProperties> = {
  sm: {
    fontSize: "clamp(1.75rem, 4vw, 2.75rem)",
  },
  lg: {
    fontSize: "clamp(1.9rem, 3.5vw, 2.75rem)",
    letterSpacing: "-0.01em",
  },
};

export function Heading({
  children,
  size = "sm",
  as = "h2",
  style,
}: {
  children: React.ReactNode;
  size?: HeadingSize;
  as?: "h1" | "h2";
  style?: React.CSSProperties;
}) {
  const Tag = as;
  return (
    <Tag
      style={{
        fontFamily: "var(--font-display)",
        fontWeight: 300,
        color: "var(--color-text)",
        lineHeight: 1.15,
        ...HEADING_STYLE[size],
        ...style,
      }}
    >
      {children}
    </Tag>
  );
}

export interface SectionHeadingProps {
  /** Small uppercase label above the title. Omit to render title-only. */
  eyebrow?: string;
  title: React.ReactNode;
  center?: boolean;
  /** Show the divider under the eyebrow. Default true when eyebrow is set. */
  divider?: boolean;
  size?: HeadingSize;
  as?: "h1" | "h2";
  className?: string;
  style?: React.CSSProperties;
}

/** Convenience wrapper for the About.tsx-style pattern: eyebrow -> divider -> title, merged. */
export default function SectionHeading({
  eyebrow,
  title,
  center = false,
  divider,
  size = "sm",
  as = "h2",
  className,
  style,
}: SectionHeadingProps) {
  const showDivider = divider ?? Boolean(eyebrow);

  return (
    <div
      className={className}
      style={{ textAlign: center ? "center" : "left", marginBottom: "3rem", ...style }}
    >
      {eyebrow && <Eyebrow center={center}>{eyebrow}</Eyebrow>}
      {showDivider && <Divider size={size} center={center} />}
      <Heading size={size} as={as}>
        {title}
      </Heading>
    </div>
  );
}
