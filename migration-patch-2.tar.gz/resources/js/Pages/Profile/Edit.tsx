import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { PageProps } from "@/types";
import { Head, usePage } from "@inertiajs/react";
import DeleteUserForm from "./Partials/DeleteUserForm";
import UpdatePasswordForm from "./Partials/UpdatePasswordForm";
import UpdateProfileInformationForm from "./Partials/UpdateProfileInformationForm";
import VendorDetails from "./Partials/VendorDetails";
import ShippingAddresses, { ShippingAddress } from "./ShippingAddresses";
import Card from "@/Components/App/Card";
import { Eyebrow, Divider, Heading } from "@/Components/App/ui/SectionHeading";

/* Local Ornament/Eyebrow removed — shared Components/App/ui/SectionHeading
   kit's defaults match this page's exact original values, so it's used
   directly below with no wrapper needed. `CardLabel` was defined here but
   never actually used anywhere in the file — removed as dead code. */

export default function Edit() {
  const page =
    usePage<
      PageProps<{
        mustVerifyEmail: boolean;
        status?: string;
        shipping_addresses: ShippingAddress[];
      }>
    >();
  const { mustVerifyEmail, status, shipping_addresses } = page.props;
  return (
    <AuthenticatedLayout>
      <Head title="Profile" />

      <div
        style={{
          fontFamily: "var(--font-body)",
          background: "var(--color-bg)",
          minHeight: "100%",
        }}
      >
        <style>{`
          .pf-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: var(--radius-md);
            padding: 2rem;
            position: relative;
            overflow: hidden;
            transition: border-color var(--transition-base), box-shadow var(--transition-base);
          }
          .pf-card:hover {
            border-color: var(--color-accent-light);
            box-shadow: var(--shadow-lg);
          }
          .pf-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--color-accent);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.4s ease;
          }
          .pf-card:hover::before {
            transform: scaleX(1);
          }
          .pf-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.75rem;
          }
          @media (min-width: 900px) {
            .pf-grid {
              grid-template-columns: 1fr 1fr;
              align-items: start;
            }
          }
          .pf-stack {
            display: flex;
            flex-direction: column;
            gap: 1.75rem;
          }
        `}</style>

        {/* ── Hero ── */}
        <section
          style={{
            background: "var(--color-bg-dark)",
            padding: "4rem 0 3rem",
            borderBottom: "1px solid var(--color-border)",
          }}
        >
          <div
            style={{
              maxWidth: "var(--container-max)",
              margin: "0 auto",
              padding: "0 7vw",
              marginLeft:20
            }}
          >
            <Eyebrow>Account</Eyebrow>
            <Divider margin="1rem 0 1.5rem" />
            <Heading as="h1" style={{ fontSize: "clamp(2rem, 4vw, 2.75rem)", color: "white" }}>
              Your{" "}
              <em
                style={{
                  fontStyle: "italic",
                  color: "var(--color-accent-light)",
                }}
              >
                Profile
              </em>
            </Heading>
          </div>
        </section>

        {/* ── Content ── */}
        <section style={{ padding: "3.5rem 0 5rem" }}>
          <div
            style={{
              maxWidth: "var(--container-max)",
              margin: "0 auto",
              padding: "0 7vw",
            }}
          >
            <div className="pf-grid">
              {/* ---------- LEFT SIDE ---------- */}

              <div className="pf-stack">
                <Card title="Profile Information">
                  <UpdateProfileInformationForm
                    mustVerifyEmail={mustVerifyEmail}
                    status={status}
                  />
                </Card>
                <Card title="Security">
                  <UpdatePasswordForm />
                </Card>
                <Card title="Danger Zone">
                  <DeleteUserForm />
                </Card>
              </div>

              <div className="pf-stack">
                <Card
                  title="Vendor Details"
                  badge={/* e.g. user.vendor?.status_label */ undefined}
                >
                  <VendorDetails />
                </Card>
                <Card title="Shipping Addresses">
                  <ShippingAddresses shipping_addresses={shipping_addresses} />
                </Card>
              </div>
            </div>
          </div>
        </section>
      </div>
    </AuthenticatedLayout>
  );
}
